#ifndef LED_H
#define LED_H

void setupLED();
void redLedOn();
void redLedOff();
void yellowLedOn();
void yellowLedOff();
void blueLedOn();
void blueLedOff();

#endif