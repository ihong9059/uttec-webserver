// switch.h
#pragma once
#include <Arduino.h>
void initSwitch();
int readSwitch(); // 0 or 1 (눌림/안눌림)
