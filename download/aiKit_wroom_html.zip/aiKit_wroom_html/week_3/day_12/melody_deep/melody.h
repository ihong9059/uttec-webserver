#ifndef MELODY_H
#define MELODY_H

void setupSpeaker();
void playMelody(int number);
void updateMelody();
void stopMelody();

#endif