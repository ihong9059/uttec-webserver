#ifndef LED_H
#define LED_H

void setupLED();
void setRedLED(int brightness);
void setYellowLED(int brightness);
void setBlueLED(int brightness);

#endif
