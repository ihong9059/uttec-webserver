#ifndef LED_H
#define LED_H

void setupLeds();
void controlLed(char color, int value);

#endif