// display.h
#pragma once
#include <Arduino.h>

void initDisplay();
void displaySetLines(const String& l1, const String& l2, const String& l3, const String& l4);
