#ifndef SENSOR_H
#define SENSOR_H

void setupSensor();
float readTemperature();
float readHumidity();

#endif