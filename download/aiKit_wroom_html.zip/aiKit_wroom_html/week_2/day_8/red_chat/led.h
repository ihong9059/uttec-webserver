#ifndef LED_H
#define LED_H

#define RED_LED 25  // Red LED 핀 번호

void initLed();
void ledOn();
void ledOff();

#endif
