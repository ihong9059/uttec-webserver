#ifndef LED_H
#define LED_H

void setupLED();
void ledOn();
void ledOff();

#endif