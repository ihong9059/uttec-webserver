// switch.cpp
#include "switch.h"

// 현재 모든 구현은 switch.h 안에 있으므로
// 확장이 필요하면 이곳에 구현을 분리하면 됩니다.
