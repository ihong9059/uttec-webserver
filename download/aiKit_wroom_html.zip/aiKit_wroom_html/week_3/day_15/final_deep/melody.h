#ifndef MELODY_H
#define MELODY_H

void setupMelody();
void playAlarm();
void playMelody(int melodyNumber);

#endif